import java.io.*;
import java.net.*;
import java.util.Arrays;

public class FiveInRowServer {
    private static final int PORT = 12346;
    private static final int SIZE = 20;
    private static final int WINNING_STREAK = 5;

    private char[][] board = new char[SIZE][SIZE];
    private PlayerHandler[] players = new PlayerHandler[2];
    private int currentPlayer = 0;

    public static void main(String[] args) {
        new FiveInRowServer().start();
    }

    public FiveInRowServer() {
        for (char[] row : board) {
            Arrays.fill(row, ' ');
        }
    }

    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Сервер запущен...");
            while (true) {
                if (players[0] == null) {
                    players[0] = new PlayerHandler(serverSocket.accept(), 'X');
                    new Thread(players[0]).start();
                } else if (players[1] == null) {
                    players[1] = new PlayerHandler(serverSocket.accept(), 'O');
                    new Thread(players[1]).start();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private synchronized boolean makeMove(int x, int y, char symbol) {
        if (board[x][y] == ' ') {
            board[x][y] = symbol;
            return true;
        }
        return false;
    }

    private synchronized boolean checkWin(int x, int y, char symbol) {
        // Проверка горизонтального, вертикального и диагонального направлений
        return checkDirection(x, y, symbol, 1, 0) || // Горизонтально
                checkDirection(x, y, symbol, 0, 1) || // Вертикально
                checkDirection(x, y, symbol, 1, 1) || // Диагональ \
                checkDirection(x, y, symbol, 1, -1);  // Диагональ /
    }

    private boolean checkDirection(int x, int y, char symbol, int dx, int dy) {
        int count = 1;
        for (int i = 1; i < WINNING_STREAK; i++) {
            if (inBounds(x + i * dx, y + i * dy) && board[x + i * dx][y + i * dy] == symbol) count++;
            else break;
        }
        for (int i = 1; i < WINNING_STREAK; i++) {
            if (inBounds(x - i * dx, y - i * dy) && board[x - i * dx][y - i * dy] == symbol) count++;
            else break;
        }
        return count >= WINNING_STREAK;
    }

    private boolean inBounds(int x, int y) {
        return x >= 0 && x < SIZE && y >= 0 && y < SIZE;
    }

    private class PlayerHandler implements Runnable {
        private Socket socket;
        private BufferedReader input;
        private PrintWriter output;
        private char symbol;

        public PlayerHandler(Socket socket, char symbol) {
            this.socket = socket;
            this.symbol = symbol;
        }

        @Override
        public void run() {
            try {
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                output = new PrintWriter(socket.getOutputStream(), true);

                output.println("WELCOME " + symbol);
                if (symbol == 'X') {
                    output.println("MESSAGE Ожидание подключения противника");
                } else {
                    players[0].output.println("MESSAGE Ваш ход");
                }

                while (true) {
                    String command = input.readLine();
                    if (command == null) {
                        break;
                    }
                    if (command.startsWith("MOVE")) {
                        String[] parts = command.split(" ");
                        if (parts.length == 3) {
                            try {
                                int x = Integer.parseInt(parts[1].trim());
                                int y = Integer.parseInt(parts[2].trim());
                                if ((currentPlayer == 0 && symbol == 'X') || (currentPlayer == 1 && symbol == 'O')) {
                                    if (makeMove(x, y, symbol)) {
                                        players[currentPlayer].output.println("YOUR_MOVE " + x + " " + y);
                                        players[1 - currentPlayer].output.println("OPPONENT_MOVED " + x + " " + y);
                                        if (checkWin(x, y, symbol)) {
                                            output.println("VICTORY");
                                            players[1 - currentPlayer].output.println("DEFEAT");
                                            break;
                                        } else if (boardFull()) {
                                            output.println("DRAW");
                                            players[1 - currentPlayer].output.println("DRAW");
                                            break;
                                        }
                                        currentPlayer = 1 - currentPlayer;
                                        players[currentPlayer].output.println("MESSAGE Ваш ход");
                                    } else {
                                        output.println("MESSAGE Неверный ход");
                                    }
                                }
                            } catch (NumberFormatException e) {
                                output.println("MESSAGE Неверный формат команды");
                            }
                        } else {
                            output.println("MESSAGE Неверный формат команды");
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private boolean boardFull() {
            for (int x = 0; x < SIZE; x++) {
                for (int y = 0; y < SIZE; y++) {
                    if (board[x][y] == ' ') {
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
