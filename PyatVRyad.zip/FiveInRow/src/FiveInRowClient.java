import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;

public class FiveInRowClient {
    private static final int SIZE = 20;
    private JFrame frame = new JFrame("Пять в ряд");
    private JButton[][] buttons = new JButton[SIZE][SIZE];
    private PrintWriter output;
    private BufferedReader input;
    static Font customFont = null;
    ImageIcon iconKrest;
    ImageIcon iconKrug;

    public static void main(String[] args) throws IOException, FontFormatException {
        new FiveInRowClient().start();
    }

    public FiveInRowClient() {
        // Загружаем иконку
        URL imgURL = FiveInRowClient.class.getResource("/resources/krest.png");
        if (imgURL != null) {
            iconKrest = new ImageIcon(imgURL);
            System.out.println("Файл открыт: resources/krestik.png");
        } else {
            System.err.println("Файл не найден: resources/krestik.png");
            iconKrest = null;  // Или установите иконку по умолчанию
        }
        // Загружаем иконку
        imgURL = FiveInRowClient.class.getResource("/resources/krug.png");
        if (imgURL != null) {
            iconKrug = new ImageIcon(imgURL);
            System.out.println("Файл открыт: resources/krug.png");
        } else {
            System.err.println("Файл не найден: resources/krug.png");
            iconKrest = null;  // Или установите иконку по умолчанию
        }
    }

    public void start() {
        frame.setLayout(new GridLayout(SIZE, SIZE));
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                final int x = i;
                final int y = j;
                buttons[i][j] = new JButton(" ");
                if (customFont != null) {
                    buttons[i][j].setFont(customFont);
                } else {
                    buttons[i][j].setFont(new Font("Arial", Font.PLAIN, 10));
                }
                buttons[i][j].setFocusPainted(false);
                buttons[i][j].addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        output.println("MOVE " + x + " " + y);
                    }
                });
                frame.add(buttons[i][j]);
            }
        }
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 800);
        frame.setVisible(true);

        try {
            Socket socket = new Socket("localhost", 12346);
            input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            output = new PrintWriter(socket.getOutputStream(), true);

            while (true) {
                String response = input.readLine();
                if (response == null) {
                    // Соединение с сервером закрыто
                    JOptionPane.showMessageDialog(frame, "Соединение с сервером потеряно.");
                    break;
                }
                if (response.startsWith("WELCOME")) {
                    char mark = response.charAt(8);
                    frame.setTitle("Пять в ряд - Игрок " + mark);
                } else if (response.startsWith("MESSAGE")) {
                    JOptionPane.showMessageDialog(frame, response.substring(8));
                } else if (response.startsWith("OPPONENT_MOVED")) {
                    String[] parts = response.split(" ");
                    if (parts.length == 3) {
                        int x = Integer.parseInt(parts[1].trim());
                        int y = Integer.parseInt(parts[2].trim());
                        buttons[x][y].setIcon(currentMark() == 'O' ? iconKrest : iconKrug);
                        buttons[x][y].setDisabledIcon(currentMark() == 'O' ? iconKrest : iconKrug);
                        buttons[x][y].setEnabled(false);
                    }
                } else if (response.startsWith("YOUR_MOVE")) {
                    String[] parts = response.split(" ");
                    if (parts.length == 3) {
                        int x = Integer.parseInt(parts[1].trim());
                        int y = Integer.parseInt(parts[2].trim());
                        buttons[x][y].setIcon(currentMark() == 'X' ? iconKrest : iconKrug);
                        buttons[x][y].setDisabledIcon(currentMark() == 'X' ? iconKrest : iconKrug);
                        buttons[x][y].setEnabled(false);
                    }
                } else if (response.startsWith("VICTORY")) {
                    JOptionPane.showMessageDialog(frame, "Вы выиграли!");
                    break;
                } else if (response.startsWith("DEFEAT")) {
                    JOptionPane.showMessageDialog(frame, "Вы проиграли!");
                    break;
                } else if (response.startsWith("DRAW")) {
                    JOptionPane.showMessageDialog(frame, "Ничья!");
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            frame.setVisible(false);
            frame.dispose();
        }
    }

    private char currentMark() {
        return frame.getTitle().contains("X") ? 'X' : 'O';
    }
}
